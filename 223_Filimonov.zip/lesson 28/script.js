﻿/*Задание 28 Номер 1*/
let str = '2025-12-31 12:59:59';
let res = str.split(/[-:\s]/);
document.write("["+res+"]");
